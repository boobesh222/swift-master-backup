//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

// initializing a String

var firstName=""
print("firstName value is\(firstName)")

var lastName=String()
lastName="lee"

print("last name value is \(lastName)")

//defining mutable and non_mutable_String

var mutable_string:String="hi"
mutable_string += " welcome to earth"
print("mutable String value\(mutable_string)")

// non mutable example
/*let non_mutable_String:String="hello"
 print("try to change me ")
 non_mutable_String += "attach me "
 print(non_mutable_String)*/


for character in "hello ! , helllo  ".characters{
    print(character)
}

//creating a character constant
let cc:[Character] = ["a","b","c","d"]
print(cc)

//converting character constant to String
let converted_String=String(cc)
print("converted String : \(converted_String)");


//String concatination same as java
var greet:String="hello "
var to:String="john "
var exclamation:Character="!"

greet += to
// can append character to a String value
greet.append(exclamation)
print(greet)

// using unicode characters
let dollerSign = "\u{24}"
print(dollerSign)

// Graphme clusters ( combining many unicode characters )
let eacute="\u{E9}"
print(eacute)
let combinedeacute="\u{65}\u{301}"
print("combined e acute :  \(combinedeacute)")
var coffee:String="cafe"
coffee += "\u{301}"
print(coffee)
print(coffee.characters.count)


// using index in swift
let welcomeMessage:String="hello  world"


print(welcomeMessage[welcomeMessage.startIndex])
// print("using after function\(welcomeMessage[welcomeMessage.index(after:welcomeMessage.startIndex)])")
print("using before function\(welcomeMessage[welcomeMessage.index(before:welcomeMessage.endIndex)])")
let indexValue=welcomeMessage.index(welcomeMessage.startIndex,offsetBy:9)
print("index value\(indexValue)" )

/*for index in welcomeMessage.characters.indices{
 print("\(welcomeMessage[index]) ",terminator:"  ")
 }*/


// inserting and removing contents at index
var message="hello "
message.insert("!" ,at:message.endIndex)
print(" messages value "+message)
let value=message[message.index(before:message.endIndex)]
print(" Index value \( value)")
//message.insert( " there".characters, at: message.index(before:message.endIndex) )
print(message)


message.remove(at:message.index(before : message.endIndex))

print(message)

let rangeVal=message.index(message.endIndex,offsetBy: -6)..<message.endIndex
message.removeSubrange(rangeVal)
print("result  string \(message)")


// comparing Strings
var Americalletter:Character="\u{41}"
print(Americalletter)
var cryllicrussianletter:Character="\u{0410}"
print(cryllicrussianletter)
if(cryllicrussianletter != Americalletter){
    print("the letters are not equal ")
}


// checking with prefix and suffix
// not working checking

let dogString = "dog !! "
for values in dogString.utf8{
    print(values,terminator:" ")
}


for values in dogString.utf16{
    print(values , terminator: " ")
}

for values in dogString.unicodeScalars{
    // print(values.value)
    
    print(values)
    
}













