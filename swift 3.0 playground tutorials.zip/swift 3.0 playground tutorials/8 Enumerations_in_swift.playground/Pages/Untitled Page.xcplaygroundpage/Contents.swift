//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// enumerations in swift
 // user defined datatype in swift with its own value 
// enum structure 

enum Planet{
  case earth
  case mars
  case jupiter
  case venus
  case uranus
}

// planet has its own datatype 
// each case has its own INT VALUE


var result = Planet.earth
result.hashValue
Planet.jupiter.hashValue

result = .uranus

result = .venus

switch result {

case .earth:
    print("3 planet")
case .mars:
    print("4 planet")
case .jupiter:
    print("5 th planet")
case .uranus:
    print("uranus ")
case Planet.venus:
    print("venus second planet")
default:
    print("printing default value ")
}


// associated value sin enumerations in swift
// asso values allows us to store additional values to the case values
// associated values create a tuple in the following example

enum barcode{
    case upc(Int,Int,Int,Int)
    case barcode(String)
 }
		
var productbarcode=barcode.upc(8, 9, 0, 1)


 productbarcode=barcode.barcode("hello again")

switch productbarcode{
case let  .upc(digitone, digittwo,digitthree,digitfour):
    print("\(digitone),\(digittwo),\(digitthree),\(digitfour)")
case let .barcode(barcodeString):
    print("barcode String is \(barcodeString)")
default:
    print("no mactching case found ,printing default ")
}

// using raw values in enumerations

enum rawex:Int {
    case one = 1
}


// implicitly assigned raw values 
// first case if value is not assigned then the value is 0
// for string the case name is taken as the raw values

enum solarSystem:Int{
case mercury = 1 ,venus,earth,mars,jupiter
}

enum fortune500:String{
    case apple,samsung,lg,siemens;
}

var planetposition = solarSystem.jupiter.rawValue
var company = fortune500.apple.rawValue

// initialization of enum from a raw values 
// this initializer returnes an optional

let possibleplanet = solarSystem(rawValue:3)
possibleplanet?.rawValue

// recursive enumerations in swift 
// have to use indirect keyword before the case or in enum syntax 
// recursive enum structure

enum arthimeticexpression{
    case number(Int)
    
    
   indirect case addition(arthimeticexpression,arthimeticexpression)
   indirect case multiplication(arthimeticexpression,arthimeticexpression)
    
}
var ten=arthimeticexpression.number(10)
var nine=arthimeticexpression.number(9)

let addition=arthimeticexpression.addition(ten, nine)










