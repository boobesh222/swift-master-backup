//: Playground - noun: a place where people can play

import UIKit
//                                                                 THE BASICS OF SWIFT LANGUAGE    


//introduction to variables

//variable example
var str = "Hello, playground"

//declaring contants
let name="swift"



//type annotation in swift
var a:Int
let b:String
var value:String

//type interference 
var booValue=true
var boo_1_value=1 // data type automatically mapped 
//  boo_1_value="hai" throws error



//numeric literals

var number:Int=10
var binaryRep:Int=0b10
var octalRep:Int=0o10
var HexaRep:Int=0x10



//numeric type conversions (int ,uint etc)
var twoThousand: Int16 = 20_000
var one: Int8 = 1
var twoThousandAndOne = twoThousand + Int16(one)
// * conversions cant be done between Int and UInt
// * same applies for int and floating point conversions




//string interpolation in swift example
print("printing the value of str \(str)")
str="hello world"
print("printing the value of str \(str)")

var primaryname:String
primaryname="steve"
var surname:String
surname="jobs"
var fullname=primaryname+" " + surname


//type aliases (defining alternate or convenient name for a datatype )
typealias numbers=Int
let height:numbers=numbers.min

typealias words=String
let rhymes:words="twinkle twinkle litte star"


// tuples in swift (“Tuples group multiple values into a single compound value. The values within a tuple can be of any type and do not have to be of the same type as each other.”
var tuples=(12,"JOhn","corner","120 ' malibu point ",234987)
let (age,namesT,_,_,_)=tuples
age
namesT
tuples.4
tuples.3
//“let values = (statusCode: 200, description: "OK")”


////Optionals in swift
// returns an optional value represented as datatype ?
//    similar to returning nil on objective c and it will not point to an empty object as same as objective c instead returns nil

let hallTicketNumber="201935"
let possibleNumber="123000000"
let convertedNumber=Int(possibleNumber)
convertedNumber



var initialOptionalValue:String?  //problem with declaring let and var initial declaration
initialOptionalValue
if convertedNumber != nil{
   print("optional value forced unwrapping\(convertedNumber!)")
}


// binding some value from an optional varible 
// variables created within if resolves only with if statement
if let actualNumber:Int? = Int(convertedNumber!) ,let newNumber = Int(hallTicketNumber){
    print(actualNumber,newNumber)
    print("optional binding\(actualNumber)")
}

// Implicitly unwrapping optional Strings
let normalWrapVariable:String?="HI am a String"
print(normalWrapVariable!)
let implicitWrapVariable:String!="HI am implicitly wrapped"
print(implicitWrapVariable)

// error handling
// mention throws keyword,while calling the function prepend TRY KEYWORD 
do{
  // try
}catch{
}

//assertions used for checking invalid conditions not working
//let assertionName:String = "Apple"
//let ages = -1
//
//assert(ages >= 0, "A person's age cannot be less than zero")





////introduction to operators
//a=1
//a=a+1
//a=a-1
//a=a+a*a
//
//var c:Float
//c=12.23
//var bfloat:Float
//bfloat=10.2
//bfloat+=30.5
//bfloat-=10.34
//c=c+bfloat





