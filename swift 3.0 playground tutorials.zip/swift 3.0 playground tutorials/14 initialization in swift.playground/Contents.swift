 //:home  Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// overroding failable initilizers in initialization

class Document {

    var name:String?
    
    init(){
    
    print("designated initializer ")
    }
    
    init?(name:String){
        if name.isEmpty{ return nil }
        self.name=name
    }
}


class AutomaticallyNamedDocument:Document{
    override init(){
        print("overrided initializer ")
       super.init()
        self.name="untiled"
    }
    
    override init(name:String){
           super.init()
        if name.isEmpty{
        
        self.name = "untitled"
        
        }else{
          self.name = name
        }
    }
}



let namesInitializerInstance  = AutomaticallyNamedDocument(name:"boobesh")
namesInitializerInstance.name

class UntitledDocument:Document{
    override init() {
       // super.init()
        super.init(name: "")!
    }
}

// the following will result in runtime execution error

//  let insi = UntitledDocument()

// implicitly unwrapping initializers with !
 // init! can be delegated up 

// init!   <---  delegate ----> init? ,init

// required initializer syntax 
// every subclass should implement this intializer if provided 

class SomeClass{
    required init(){
       print("required intializer ")
    }
}

class SomeSubClass:SomeClass{
    required init(){
      print("somesubclass requiered intializer ")
    }
}

let subclassInstance = SomeSubClass()

// setting default property value with closure or function
// no variables, self ,and other stored properties are  executed inside the closure 
// this is executed while the type initialization takes place 
// the syntax should be followed by () paranthesis to indicate a value is returned and not a closure is returned 


struct Chessboard{
    let chessBoardColours:[Bool]={

        var temporaryBoard=[Bool]()
        var isBlack = false
        
        for i in 1...8{
           print(i)
            for j in 1...8{
                print(j)
                temporaryBoard.append(isBlack)
                isBlack = !isBlack
            }
            
            isBlack = !isBlack
        }
        
        
        
        return temporaryBoard
        }()


    func squareIsBlackAt(row:Int , column:Int)-> Bool{
        
        if chessBoardColours[row*8 + column]{
           print ("white colour ")
        }else {
             print("black colour")
             return false
        
        }
        return chessBoardColours[row*8 + column]
        
    }
   
}


let chessboardstruct = Chessboard()
chessboardstruct.squareIsBlackAt(row: 1, column: 4)
 
 
 
 
 // muthu mac 
 
 //  Write some awesome Swift code, or import libraries like "Foundation",
 //  "Dispatch", or "Glibc"
 // http://swiftlang.ng.bluemix.net/#/repl/583e79583d1afb526a720902
 // recent          http://swiftlang.ng.bluemix.net/#/repl/584170981965df4531b953b5
 // optional handling in swift -- http://swiftlang.ng.bluemix.net/#/repl/58480ebf9478f667c5d6f72a
 
 
 // initialization in swift
 // process of preparing an instance and setting initial value of property
 // swift initializers do not return a value
 
 
 // init method can be used
 
 // initializers just like instance method
 
 
 class initializationExample{
    var temperature:Double
    init() {
        temperature = 25
    }
 }
 
 
 var instance = initializationExample()
 print("temperature is currently \(instance.temperature)")
 
 
 // customizing initialization
 
 // initialization with parameters
 
 struct Celsius{
    var temperatureInCelsius:Double
    init(fromFarenheit farenheit:Double){
        temperatureInCelsius = (farenheit - 32.0)/1.8
        print("temperatureInCelsius \(temperatureInCelsius)")
        
    }
    
    init(fromKelvin kelvin:Double){
        temperatureInCelsius = kelvin-273.15
        print("temperatureInCelsius \(temperatureInCelsius)")
        
        
    }
    
    init(_ truecelcius:Double){
        temperatureInCelsius = truecelcius
        print("temperatureInCelsius \(temperatureInCelsius)")
        
    }
 }
 
 
 var celcius = Celsius(fromFarenheit:87)
 var kelvin = Celsius(fromKelvin:453)
 
 
 // should use argument label is provided else will result in compile time error
 
 // if argument label is not needed for use use underscore in place of argument label
 
 var wtemperature = Celsius(43)
 print(wtemperature)
 
 
 // optional property types
 
 class Surveyquestion{
    
    var Question:String
    var response:String?
    // let optionalAnswer:String
    
    init(){
        
        Question = "what do you like the most ? "
        // optionalAnswer = "not the fruit "
        print("question : \(Question)")
        // print("optional answer \(optionalAnswer)")
    }
    
    
 }
 
 
 var survey = Surveyquestion()
 print(survey.response)
 
 survey.response = " Apple "
 print(survey.response!)
 
 // assigning value for constants 
 

 
 // others 
 
 
 
 //: Playground - noun: a place where people can play
 
 import UIKit
 
 // var str = "Hello, playground"
 // initializer delegation in swift
 // use self.init to refer to other initializer of the same type
 
 
 // defining cuatom initializer will prevent access to default initializers in structure
 
 struct Point {
    var x = 0.0 ,y = 0.0
 }
 
 struct Size{
    var width = 0.0 ,height = 0.0
 }
 
 struct rect{
    var origin = Point()
    var size = Size()
    
    
    // default initializers
    init(){}
    
    // memberwise initializers
    
    init(origin:Point ,center:Size){
        self.origin = origin
        self.size = center
        print("member wise initializer invoked with the origin and center value ")
    }
    
    // delegates which call other method
    init(center:Point,size:Size){
        
        let originX = center.x - (size.width/2)
        let originY = center.y - (size.height/2)
        
        // invokes other initializer from this initializer
        self.init(origin:Point(x:originX, y:originY),center:size)
        
    }
    
 }
 
 
 let rectangleCoordinates = rect(center:Point(x:3,y:7),size:Size(width:76,height:99))
 
 
 // class type initializers
 // two types 1) designated initializers and 2)convinience initializers
 
 // designated initiailzers are the default initilaizers fot the class.initialization happens upto super class chain
 
 // convinience initializers are the secondary initializers for the class
 
 // create convinience initializer for shorter and clearer initialisation process .use them to initialize designated initializer
 
 // designated and convinience syntax as follows
 
 
 //  init( paramenters ){
 
 //   }
 
 //  convience init( parameters ){
 
 //  }
 
 // refer initializer delegation and two phase delegation 
 
 // refer for more examples 
 
 
 
 
 
 
