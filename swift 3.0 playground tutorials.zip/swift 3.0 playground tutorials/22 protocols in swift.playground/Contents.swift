//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// protocol contains methods and properties what that class or type will contain 

// protocol syntax 

protocol someprotocol{
    
    
 // some implementations
}

//  how to adopt a protocol 
struct somestruct:someprotocol{
  // implement protocol methods and functions 
    
}

class someclass:someprotocol{
}
// super class should come first followed by the protocol 

// property requirements for the protocol 

// type should conform to that protocol to implement types 
//  protocol types should be implemented with get or set method 
// type property should have a static keyword

protocol fullyNamed{
    var fullName:String{get}
    
}

class Starship:fullyNamed{
     var fullName: String
    
    init(name:String){
        fullName = name
       print("star ship initialized and name is alloted ")
    }
}

var starshipInstance:Starship? = Starship(name:"mangalyann ")
starshipInstance!.fullName

// method requirements
// no method body allowed in protocol 
// static or class  keyword for type method also

// protocol with type method requirement implemented
protocol someProtocol{
    static func someFunction()
}


// protocol with class method implemented
protocol RandomNumberGenerator{
   func generateRandomNumber()->Double
    static func greetUser()
}

class LinearCongruencialGenerator:RandomNumberGenerator{
   var lastRandom = 42.0
    let m = 23.3455
    let a = 567.99
    let c = 875.87
    
    func generateRandomNumber() -> Double {
        lastRandom = (a*lastRandom+c).truncatingRemainder(dividingBy: m)
        return lastRandom
    }
    // type method implementation
    static func greetUser() {
        print("Random number generated")
    }
}

let generator = LinearCongruencialGenerator()
generator.generateRandomNumber()
generator.generateRandomNumber()
generator.generateRandomNumber()

LinearCongruencialGenerator.greetUser()


// mutating methods requirements ,use mutating keyword 

protocol Toggle{
    mutating func toggle()
}


enum OnOffSwitch:Toggle{
   case On,Off
    mutating func toggle() {
        switch self {
        case .On:
            self = .On
            print("the light switch is on ")
        case .Off:
            print("the light switch is off ")
            self = .Off
        default:
            print("no value is found")
        }
    }
    
}

var lightSwitch = OnOffSwitch.On
lightSwitch.toggle()

// protocols as initializers .. 

protocol someInitializersprotocol{
    init()
}

class alphabet{
    init(){
        print("alphabet class initializer ")
    }
}
// use required keyword in subclass and inherited types 

class poem:alphabet,someInitializersprotocol{
   
    required override init(){
       print("some protocol insatnce initialized")
       super.init()
    }
}


var poemInstance = poem()

// protocols as types 

class Dice{
    let sides:Int
    let generator:RandomNumberGenerator
    init(sides:Int,generator:RandomNumberGenerator) {
        self.sides = sides
        self.generator = generator
    }

    func roll()->Int{
       return  Int(generator.generateRandomNumber())
    }
}

var dice = Dice(sides:6,generator:LinearCongruencialGenerator())
dice.roll()
dice.roll()
dice.roll()
// delegation  -- handing over control to other instance 
















