//: Playground - noun: a place where people can play

import UIKit

// swift contains many new operators such as overflow ,range operators

// two different operators prefix and postfix

// assignment operators 

//                 does not return a value

// compound assignment operator combining arthimetic with assignment operators
var a = 10
    a += 2

// ** have a skim on comparative operators in  swift.

// tuples can be compared in swift.

var nameDetails:(String,Int)=("steve",45)
let fatherNameDetails:(String,Int) = ("john",45)
nameDetails.0 > fatherNameDetails.0
if(nameDetails.0 == fatherNameDetails.0){
}else{
    print("hi values are not equal ");
}

// nil coalescing operator
var companyname:String?="apple"
var ceoname:String="tim cook"

companyname ?? ceoname

// range operators in swift * closed range operators and half range operators
for index in 1...10000{
 print(index)
}

for index in 1..<10000{
  print(index)
}

var names=["apple ", "batminton","camel ","dutch "]
for index in 0..<names.count{
    print(names[index])
}

