//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

print("Hello world!")

// nested types in swift

// example with nested struct and enum


struct BlackJackCard{
    
    enum suit:Character{
        case spades = "s" ,heart = "h" ,diamonds = "d",clubs = "c"
    }
    
    enum rank:Int{
        
        case two = 2,three,four,five,six,seven,eight,nine,ten
        case jack,king,queen,ace
        struct values{
            
            let first:Int,second:Int?
        }
        
        var value:values{
            switch self{
                
            case .ace:
                return values(first:1,second:11)
                
            case .jack , .king , .queen :
                return values(first:10,second:nil)
            default :
                return values(first:self.rawValue,second:nil)
            }
        }
        
    }
    
    
    let ranks:rank,suits:suit
    var  descriptions:String{
        var output =  "the suit is \(suits.rawValue) and value is \(ranks.value.first) "
        
        if let second = ranks.value.second  {
            output += "the second is \(ranks.value.second)"
            
            
        }
        return output
    }
}

let theAceOfSpades = BlackJackCard(ranks:.ace,suits:.spades)

print(" \(theAceOfSpades.descriptions)")


let heartSymbol = BlackJackCard.suit.heart.rawValue
print("the value of heart is \(heartSymbol)")





