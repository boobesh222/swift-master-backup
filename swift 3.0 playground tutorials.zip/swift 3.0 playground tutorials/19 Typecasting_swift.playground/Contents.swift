// type casting in swift

//  is and as keywords used to cast and check the values in swift

// defining class hierarchy for type casting

class MediaItem{
    var name:String
    init(name:String){
        self.name = name
    }
}


class Movie:MediaItem{
    var director:String
    init(name:String,director:String){
        self.director = director
        super.init(name:name)
    }
}


class song:MediaItem{
    var artists:String
    init(name:String,artists:String){
        self.artists = artists
        super.init(name:name)
    }
}


var library=[Movie(name:"iruvar ",director:"maniratnam"),song(name:"pachai nirame",artists:"hariharan"),Movie(name:"alaipayuthey",director:"mani ratnam")]

for item in library{
    print(item)
    
}

// checking type
// use typecheck operator ----- is

var movieCount  = 0
var songCount = 0

for item in library{
    print(item)
    
    if item is Movie{
        movieCount += 1
    }else if item is song{
        songCount += 1
    }
    
}


print("the movie count \(movieCount)")
print("the song count \(songCount)")


// downcasting and upcasting  use as keyword and optional as? and as!

for item in library{
    if let movie = item as? Movie{
        print("movie name \(movie.name) by director \(movie.director)")
        
    }else if let song = item as? song{
        print("song name \(song.name) by artists \(song.artists)")
    }
}

// casting is simply treating and accessing an instance of type to which it has been casted

// type casting for any and anyobject


var things = [Any]()

things.append(0)
things.append(3.14)

things.append("hello")
things.append(Movie(name:"kabali",director:"ranjith"))
things.append({(name:String)->String in  return "hello \(name)"})


for thing in things{
    switch thing{
        
    case 0 as Int:
        print("0 as an int")
    case is  Double :
        print("3.14 as double")
    case let someString as String:
        print("string values")
    case let movie as Movie:
        print("movie as movie\(movie.name)")
    case let stringConvertor as (String) -> String:
        print(stringConvertor("boobesh"))
    default:
        print("printing default value ")
        
        
        
    }
    
    
    
    
}

// optional should be casted

