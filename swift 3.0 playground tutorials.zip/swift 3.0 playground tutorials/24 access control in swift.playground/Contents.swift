//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// access types in swift
// function types 
//: Playground - noun: a place where people can play

import UIKit


// access control in swift


//  same as access modifiers in swift

// modules and source files
// module is a single unit of code distribution -- collection of codes can be used by import keyword .each build target(app bundle or library or framework is treated as module)
// source code files are the files with in the modules


// five different access levels in swift

// open access , public access , private access ,internal access ,file private access


// open access and public access can be accessed from  any part of the defyning module and the adoption

// internal access enables access from any source files from inside the module and not from outside the module

// file private access enables access from only the source file which  is written inside the module ...the codes are only file specific

// private access can be used only within the declaration


// refer access controls in swift
// open access applies only to class and class members

// access control syntax

public class SomepublicClass{}
internal class SomeInternalClass{}
fileprivate class SomeFilePrivateClass{}
private class SomePrivateClass{}

public var somePublicVariable = 0
internal let someIntenalConstant = 0
fileprivate func someFilePrivateFunction() {}
private func somePrivateFunction(){}


// access specifiers are by default internal and the above mentioned specifiers with the internal keyword can be written without the internal keyword


// public types will have only internal members and not public members


public class SomePublicClass{
    // explicitly defined internal class
    public var somePublicProperty = 0  // explicitly public class member
    var somePubvariable = 0 // implicit class member
    fileprivate func someFilePrivateFunction(){} // ex file private function
    private func somePrivateFunction() {} // explicitlt private function
    
}

class someInternalClass{
    var someIntenalProperty = 0 // implicitly declared class property
    fileprivate func someFilePrivateFunction(){} // ex file private function
    private func somePrivateFunction() {} // explicitlt private function
    
    
}

fileprivate class someFilePrivateClassMember{
    
    func someprivatemethod(){} // implicitly fileprivate class member
    
    private func someprivateMethod(){} // private class member
    
    
    
}


private class SomeClass {
    // explicitly private class
    
    func somePrivateMethod(){}
    // explicitly private method
    
}


// access level in tuple types

// need the continuation from muthupalani's system 


//class someInternalClass{
//
//}

private class somePrivateClass{

}


// the following function will compile but throws return type error 

// private func someFunction()->(someInternalClass,somePrivateClass){

// }

// each case receives the public access specifier
public enum compass{
    case north ,south,east,west
}

// subclass in access control 

public class A{
    fileprivate func someFunction(){}
}

// overrides can provide highest access level to a method 

internal class B:A{
    override public   func someFunction() {
        super.someFunction()
    }
}


// constants ,variables ,properties and subs
// mark as public and see the difference ,since someprivate class is private ,file private the variable cant be marked public left hand side should have higher inheritance level in the context

private var classInstance = somePrivateClass()

// getters and setters normally receive the same access level as the same as variables
// setter can be given a low access value than the getter to restrict the read write scope 
// this rule applies to stored as well computed property 

// to assign low access levels the syntax is as follows -> fileprivate(set) , private(set),internal(set)
// before var and subscript syntax 

public struct trackedString{
   // setting the private{set} property 
    private(set) var numberOfEdits = 0
    var value:String = ""{
        didSet{
            numberOfEdits += 1
        }
    }
    
    
    // used to initialize this type from another module since this type is declared public
    public  init(){
        print("public type with the public initializers ")
    }
}


var stringToEdit = trackedString()

stringToEdit.numberOfEdits

stringToEdit.value = "the source value is setted "

stringToEdit.numberOfEdits

// custom initializers initialize less than or equal to the type they initialize 
// requires initializers should have the same accesslevel as the class have 

// functions and methods cant be more accessible than the initializers own access levels 


// memberwise initializer of a struct type is considered private if the structures stored property is private ,fileprivate if fileprivate,else considered internal 

// access levels in protocols 
// protocol members inherit the same access level as the protocol 















































