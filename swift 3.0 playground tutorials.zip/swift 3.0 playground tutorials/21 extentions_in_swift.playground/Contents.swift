//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// extentions add new functionalty to existing types ,structures ,classes etc 

// retroactive modelling in swift .. provides access to the source code of class 

// use extension keyword  extension sometype { }

// extend an existing type and make it adopt a protocol ,protocol name should be the same in this case

// making a extension conformance to a protocol ... syntax

// extension sometype:someprotocol,anotherprotocol {}

// consider the inputs are in meter

extension Double{
    var km:Double{return self*1_000.0}
    var feet:Double{return self/3.28084}
    
}

let valueInKilometer = 23.65.km
let valueInFeet = 234.feet

// 234 meters conveted to feet 

let aMarathon = 42.km + 1.km

print("a marathon is \(aMarathon) long")

// extensions in  initializers,extensions can add only convinience initializers to a class but not designated initializers 

struct Point {
   var x = 0.0 ,y = 0.0
    
}


struct Size{
    var width = 0.0 ,height = 0.0
}

struct Rect{
    var origin = Point()
    var size = Size()
}

let defaultRectangle = Rect()
let parameterizedRectangle = Rect(origin:Point(x:56,y:78),size:Size(width:65,height:45))
print(parameterizedRectangle.origin )


//extension for a initializer 

extension Rect{
    init(center:Point,dimensions:Size) {
        print("extended initializer ")
    }
}


let extendedRecTangle = Rect(center:Point(x:56,y:78),dimensions:Size(width:65,height:45))

// extentions on methods 

extension Int{
    func repetition(task:()->Void){
        for _ in 0..<self{
            task()
        }
    }
}

4.repetition {
    print("hai buddy")
}

// mutating instance method 

// a extension can modify a instance too . . should be marked with mutating keyword

extension Int{
    mutating func square(){
             self = self * self
    }
}

var someInt = 8
someInt.square()


// subscripts in extensions 

extension Int{
    subscript(digitIndex:Int)->Int{
    
        var decimalPlace = 	1
        for _ in 0..<digitIndex{
           decimalPlace *= 10
            print("decimal place value\(decimalPlace)")
        }
       print("self divided by decimal place \(self/decimalPlace)")
        return (self/decimalPlace)%10
    }
}

123456[3]


// nested types in swift 


extension Int{
    enum Kind{
        case negative,zero,positive
    }
    
    var numberKind:Kind{
        switch self {
        case 0:
            return .zero
        case let x where  self > 0:
            print("x value is \(x)")
            return .positive
        default:
            return .negative
        }
    }
}


var resultOfNumberKind = -8
var result = resultOfNumberKind.numberKind
switch result{
case .positive:
    print("++++++")
case .negative:
    print("-------")
default:
    print("the number is zero")
}
















