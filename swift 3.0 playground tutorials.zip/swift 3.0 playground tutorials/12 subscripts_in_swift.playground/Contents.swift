
// subscripts in swift

// set and retrive values by index without setting and getting specific methods

// used to query an instance in swift

// subscript keyword must be used
// subscripts accessed based on type name followed by [value ]

struct TimeTable{
    let multiplier:Int
    subscript(value:Int)->Int{
        
        return multiplier * value
    }
}

var threetimestable = TimeTable(multiplier : 3)
print(threetimestable[6])
/*
 var numberOfLegs = [ "spider ":8,"ant":6,"elephant":4]
 numberOfLegs[]*/

var numberOfLegs = ["spider":8,"ant":6,"cat":4]
numberOfLegs["bird"]=2

print(numberOfLegs["spider"])

// subscripts cant use inout parameters ,default values
// subscript will accept variadic parameters
//  subscript can take any number of input arg


struct matrix{
    let rows:Int, columns:Int
    
    var grid:[Double]
    init (rows:Int ,columns:Int){
        
        self.rows=rows
        self.columns=columns
        grid = Array(repeating:0.0 , count:rows * columns)
    }
    
    
    func IndexIsValid(row:Int , column:Int)-> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
    }
    
    subscript(row:Int , column:Int)-> Double {
        get{
            assert(IndexIsValid(row:row,column:column),"Index out of range ")
            return grid[(row*columns)+column]
        }
        set{
            grid[(row*columns)+column] = newValue
        }
    }
    
}

// get matrix struct instance

var matrixIns = matrix(rows:2, columns:2)
matrixIns[0,1] = 23
matrixIns[1,0] = 54

print(matrixIns[0,1])
print(matrixIns[1,0])

