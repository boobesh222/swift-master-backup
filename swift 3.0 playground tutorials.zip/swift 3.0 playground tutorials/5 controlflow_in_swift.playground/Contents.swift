//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"




print("Hello world!")

// control flow in Swift

// * for in  same as for ,for each in other languages
// * while same
// * repeat while (same as do while in other languages)

// * switch same as other languages
// switch in swift contains compound case statements

var grade:String = "a"
var rank : Int = 12
switch grade{
// compound case example
case "a","A":
    print("A,a found ")
case "a" :
    print("case value is a ")
case "A":
    print("matching grade A found")
    
default :
    print("no matching grade found ")
}

switch rank{
case 1..<5 :
    print("number is in range 1..4")
case 10..<20 :
    print("rank  is in range 10 .. 20")
default :
    print("default value ")
}

// switch case using a tuple
var someValue=(6,2)
print(someValue)
switch someValue {
case (1...5,3...7):
    print("some value resides under case one")
    
case (-6...9,-8...5) :
    print("some value resides under case two")
    
default :
    print("default values")
}


// value bindings inside case and use of where clause inside case
let values=(4,0)
switch values{
case (let x,0) where x == 2 :
    print("the value of x is \(x)")
case (let x,0) where x == 4:
    print("the value of x is \(x)")
case (1,1):
    print("the values are not inside case 2")
default:
    print("this is default loop")
}

// compound cases can also include optional binding
let coordinates=(9,1)
switch coordinates{
case (let x,1),(9,let x):
    print("values of x \(x) ")
default :
    print("in default case ")
}

// control statements
// continue
// iterates the loop from the begining
let comprehensions="Greatminds think alike"
var filteredWords:String=""
for i in comprehensions.characters{
    switch i{
    case "a":
        print("charcater is A")
        fallthrough
    case "e","a":
        print("character is e")
        continue
    default:
        filteredWords.append(i)
        print(filteredWords)
    }
}

// break statement normal use as of in other languages
// fallthrough  mentioned in previous switch loop
// check for early exit concepts 





















