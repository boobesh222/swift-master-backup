//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// functions in swift 

// func keyword to be used example of function structure
// string is the return type person is the parameter with its type as String

func greet(person:String) -> String{

    let greeting:String = "Hello,"+person+"!"
    return greeting
}

// person is the argument label
// invoking a function 
// function wrapped in a call to print 

greet(person: "boobesh")
// function without parameters
func helloworld()-> String{
    return "hello world"
}

helloworld()

// func with multiple parameters 

// with no written type mentioned it returnes void
func helloworld(person:String ,alreadyGreeted:Bool){
    
    if(alreadyGreeted){
       print("hello again\(person)")
    }else{
       print("hello \(person)")
    }
    
}



helloworld(person: "Boobesh", alreadyGreeted: true)

// function without return values

func printAndCount(name:String)->Int{
   print(name)
    return name.characters.count
}

func printWithoutCounting(name:String){
     printAndCount(name: name)
}

printWithoutCounting(name: "Sensiple software solutions")

// function with multiple return values


func minmax(Inputarray:[Int])->(minNumber:Int,maxnumber:Int){
    
    if Inputarray.isEmpty {
        return (0,0)
    }
       var currentmin=Inputarray[0]
       var currentmax=Inputarray[1]
    for value in Inputarray[0..<Inputarray.count]{
        print("for loop current value \(value)")
        if value < currentmin{
            currentmin = value
            print("current min \(currentmin)")
        }else if(value > currentmax) {
            currentmax = value
            print("current max \(currentmax)")
        }
    }
    return(currentmin,currentmax)
}

let sampleArray:[Int] = [87,465,73,7639,281,4872]
var result = minmax(Inputarray: sampleArray)

// accessing the return tuple
print("min value returned from the array\(result.0) and maximum value is \(result.maxnumber))")

// making return type as optional 
func Starting_letter() ->(String?){
    return nil
 
}

var firstletter:String? = Starting_letter()
print(" printing first lettter \(firstletter)" )


// parameter label and argument label examples
func greet (person:String, from city:String){
print("\(person ) is from  \(city) city")
}
// from is called the argument label

// if argument label declared it should be used for function calling
greet(person: "boobesh ",from:" new york")

// default values in functions examples 
func defaultValues(dynamic:Int,StaticParameter:Int = 12 ){
    print("dynamic values\(dynamic) and staic values \(StaticParameter)")
}

defaultValues(dynamic: 211, StaticParameter: 34)

// note the output for this type of function call
defaultValues(dynamic: 66 )

// variadic parameters in swift 

func calculateArithemeticMean(numbers:Double...){
    for number in numbers {
        print(number)
    }
}

calculateArithemeticMean(numbers: 1,2,3,4,5,6,7,8)

// inout parameters in swift 
// inout keyword is used before parameter type declaration 
// ambersand & used to denote inout parameter explicitly

func swapTwoNumbers(_ a:inout Int,_ b :inout Int){
    let temA = a
    a = b
    b = temA
    
}

var numberOne = 2
var numberTwo = 6

swapTwoNumbers(&numberOne, &numberTwo)

print ("number one and two values \(numberOne) ,\(numberTwo)")

// function types in swift examples
// in swift func of type int ,int and return type as int is possible 
// upcoming example constant or variable as function type 


func addtwoints(_ a:Int,_ b:Int) -> Int{
   print("add two points")
    return a+b
}
print("before math function declaration")
var mathFunction: (Int, Int) -> Int = addtwoints
//var multiplyfunction:(_ a:Int,_  b:Int) -> Int = addtwoints

mathFunction(1,2)

// example of swift's type inference 
let example = mathFunction(3,7)


func divideNumbers(_ a:Int,_ b:Int) -> Int {
     print("division function called ")
    return a/b
}


// function types as parameter types

func printresult(_ mathFunctions:(Int,Int) -> Int,parameterOne:Int,parametertwo:Int){
    print("the result is\(mathFunction(parameterOne,parametertwo))")
}

printresult(divideNumbers,parameterOne: 34, parametertwo: 9)


// muthu _ mac 

//var str = "Hello, playground"
// function types as return types

func moveStepForward(_ a:Int)->Int{ 
    return a+1
}

func movestepBackward(_ b:Int)->Int{
    return b-1
}

var currentValue = 3

func chooseStep(state:Bool) ->Int{
    return state ? moveStepForward(currentValue) : movestepBackward(currentValue)
}

chooseStep(state: currentValue>0)
let moveNeartozero = chooseStep(state: currentValue<0)

while(currentValue < 100){
    currentValue = chooseStep(state: currentValue>0)
}



// nested return types in swift
//func isString(_ a:Int)->(Bool) ->Int{
//   return a = Int ? moveStepForward(a):movestepBackward(a)
//}




