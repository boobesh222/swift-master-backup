//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"
// http://swiftlang.ng.bluemix.net/#/repl/583e79583d1afb526a720902
// recent          http://swiftlang.ng.bluemix.net/#/repl/584170981965df4531b953b5
// optional handling in swift -- http://swiftlang.ng.bluemix.net/#/repl/58480ebf9478f667c5d6f72a


// initialization in swift 
// process of preparing an instance and setting initial value of property
// swift initializers do not return a value 


// init method can be used 

// initializers just like instance method 


class initializationExample{
    var temperature:Double 
    init() {
        temperature = 25
    }
}


var instance = initializationExample()
print("temperature is currently \(instance.temperature)")


// customizing initialization 

// initialization with parameters

struct Celsius{
    var temperatureInCelsius:Double
    init(fromFarenheit farenheit:Double){
        temperatureInCelsius = (farenheit - 32.0)/1.8
     print("temperatureInCelsius \(temperatureInCelsius)")
        
    }
    
    init(fromKelvin kelvin:Double){
        temperatureInCelsius = kelvin-273.15
     print("temperatureInCelsius \(temperatureInCelsius)")
     
        
    }
    
    init(_ truecelcius:Double){
        temperatureInCelsius = truecelcius
     print("temperatureInCelsius \(temperatureInCelsius)")
        
    }
}


var celcius = Celsius(fromFarenheit:87)
var kelvin = Celsius(fromKelvin:453)


// should use argument label is provided else will result in compile time error 

// if argument label is not needed for use use underscore in place of argument label

var wtemperature = Celsius(43)
print(wtemperature)


// optional property types 

class Surveyquestion{
    
    var Question:String
    var response:String?
   // let optionalAnswer:String 
    
    init(){
    
        Question = "what do you like the most ? "
     // optionalAnswer = "not the fruit "
       print("question : \(Question)")
     // print("optional answer \(optionalAnswer)")    
    }
    
    
}


var survey = Surveyquestion()
print(survey.response)

survey.response = " Apple "
print(survey.response!)

// assigning value for constants 
