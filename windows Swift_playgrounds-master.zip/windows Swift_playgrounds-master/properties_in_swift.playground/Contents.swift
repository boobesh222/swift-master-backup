//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// properties in swift
// *******
// properties associate a value with class ,structure and enum 
// are of 2 types 
// * computed and stored
// * computed properties provided by class structure and enum
// * stored properties provided by class and structure only
// * type properties --->properties associated with itself


// property observers observe the changes in properties values


// stored properties --> constant or variable with object reference 
// default stored properties -->  values assigned by default 

struct FixedLengthRange{
    var height:Int
    let width:Int
}

var rangevalues = FixedLengthRange(height:2 ,width:79)
rangevalues.height=12
// rangevalues.width=3  does'nt work with constants

let constantrangevalues = FixedLengthRange(height:23,width:5)
// constantrangevalues.height=1 wont work with constant initialization 


// lazy stored properties uses lazy modifier 

// initial value is not calculated unless first time it is used 

// usefull when the properties depent on outside factors 

class DataImporter{
    var filename="data.txt"
    
}

class datamanager{
    lazy var importer=DataImporter()
    var allowedFileExtensions=[String]()
}


let manager = datamanager()
manager.allowedFileExtensions.append(".exe")
manager.allowedFileExtensions.append(".jpeg")

// dataimporter is initialised only when importer is accessed


manager.importer.filename


// computed properties 
// it has getter and setter for getting and setting values 


// ** computed properties should always be declared as variable  and not constant  **

struct Point{
  var x = 0.0, y=0.0
}

struct Size{
  var width = 0.0 ,height = 0.0
}

struct rect{
 var origin = Point()
    var size = Size()

    var center:Point{
        get{
           let centerX = origin.x + (size.width/2)
            let centerY = origin.y + (size.height/2)
            return Point(x:centerX , y:centerY )
        }
        
        set{
            origin.x = newValue.x + (size.width/2)
            origin.y = newValue.y + (size.height/2)
            
        }
    }
}

//set(x)    **    important      **




// setter method one more shorthand notation example if x is not mentioned as the parameter

// a (newValue) parameter is by default created and used

// initializing struct rectangle 

var square = rect(origin: Point(x:0.0 , y:0.0) ,size: Size(width:10.0,height:10.0))
square.origin.x
square.origin.y
square.size.width
square.size.height


var getterValue = square.center
getterValue.x
getterValue.y



square.center=Point(x:15 , y:12)
square.center.x
square.center.y


// the square is called as the computed property in swift
// simply calling square invokes getter value and setting the value using a assignment operator sets the value to the variable using the  setter method

// computed property with only getter is called read only computed property 

struct cuboid {
  var height = 9.0, width_of_cuboid = 10.0 ,depth = 7.0
    var volume:Double{
      return height*width_of_cuboid*depth
    }
}

// volume a read only property
var volume_of_cuboid = cuboid().volume



// property observers are invoked when the values are changed
// 2 observers 
// willset and didset 

class StepCounter{
 
    var totalstepcount:Int = 0{
        willSet{
           newValue
        }
        didSet{
         print(oldValue)
        }
     
    }
 
}


var newstepcounts = StepCounter()
newstepcounts.totalstepcount = 200
newstepcounts.totalstepcount = 345
newstepcounts.totalstepcount=1000


// type properties . properties of type itself 




