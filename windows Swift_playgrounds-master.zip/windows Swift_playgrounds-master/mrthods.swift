//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

print("Hello world!")


// instance method in swift 
// accessible only by class instance 
// accessed using .properties 

class counter{
    var count = 0 
    func increment(){
         count += 1
         print(count)
    }
    
    func increment(by amount:Int){
        count += amount 
        print(count)
    }

    
    func reset(){
        count = 0
        print("counter reseted ")
    }
}


let counterInstance = counter()
counterInstance.increment()
counterInstance.increment()

counterInstance.increment(by :100)

counterInstance.reset()

// instance of every type have self property
// self refers to the same instance 

struct point{
    var x = 0.0 ,y = 0.0
    func calculate(x:Double) -> Bool{
        print("print function called ")    
        var comparitionresult = self.x < x
        print(comparitionresult)
        return  comparitionresult
    }
    
    
}

let pointIns = point(x:6,y:9)

if pointIns.calculate(x:90){
    print("yes the value is greater ")
}


// mutating a property of struct 

struct coordinates {
    var x = 0.0 ,y = 0.0
    
    mutating func calculate(x:Double) {
        print("print function called ")    
           self.x = x   
         print ("mutated x value in swift  \(x)")
        
    }
    
    
}

var mutatingInstance = coordinates()
mutatingInstance.calculate(x:23)

// assigning self with in a mutating method 

struct mutatingselfproperty{
     var x = 7,y = 3
     mutating func changingself(){
        self = mutatingselfproperty(x: 45, y: 32) 
       print("changed self value \(self.x) and \(self.y)")
         
     } 
}


var example = mutatingselfproperty()

example.changingself()

// mutation on enumerations 

enum tristateswitch{
    case off,low,high   
    
    mutating func next(){
       switch self{
        case .off:
           self = .low
        case .low:
           print("assigning self value ")
           self = .high
        case .high:
           self = .off
    }    
    }
    
    
}

var switchvalues = tristateswitch.low
switchvalues.next()


// switch value now contains self object pointing to .high 

// type methods 

struct LevelTracker{
    static var highestUnlockedLevel = 1
    var currentlevel = 1
    
    static func unlock(_ level:Int){
        if level > highestUnlockedLevel{
            highestUnlockedLevel = level
        }
    }
    
    static func isUnlocked(_ level:Int)-> (Bool){
        
        return level <= highestUnlockedLevel
    }

    mutating func advance(to level:Int) -> Bool{
        
        if LevelTracker.isUnlocked(level){
            currentlevel = level
            return true
        } else{
            return false 
        }
    
        
    }
}

 class player{
     var tracker = LevelTracker()
     let playerName:String 
     func complete(level:Int){
         LevelTracker.unlock(level + 1 )
         tracker.advance(to :level+1)
     }
     
     init(name:String){
         playerName = name
     }

 
 }

var playername = player(name: "boobesh")
playername.complete(level:5)
print("highestUnlockedLevel \(LevelTracker.highestUnlockedLevel)")

playername = player(name  :"prabhu ")
if playername.tracker.advance (to: 4){
    print("player is now on level 4")
}else {
    print("level 4 has'nt been unlocked ")
}












