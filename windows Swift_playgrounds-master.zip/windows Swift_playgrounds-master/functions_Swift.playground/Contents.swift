//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// function types as return types

func moveStepForward(_ a:Int)->Int{
   return a+1
}

func movestepBackward(_ b:Int)->Int{
   return b-1
}

var currentValue = 3

func chooseStep(state:Bool) ->Int{
    return state ? moveStepForward(currentValue) : movestepBackward(currentValue)
}

chooseStep(state: currentValue>0)
let moveNeartozero = chooseStep(state: currentValue<0)

while(currentValue < 100){
  currentValue = chooseStep(state: currentValue>0)
}



// nested return types in swift 
//func isString(_ a:Int)->(Bool) ->Int{
 //   return a = Int ? moveStepForward(a):movestepBackward(a)
//}