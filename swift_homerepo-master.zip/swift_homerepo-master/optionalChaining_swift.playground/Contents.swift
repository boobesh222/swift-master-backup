// optinal chaining in swift

// process of quering and calling properties

// multiple chains can be queried together and it fails if any one query fails
// and returns nil

// optional chaining an alternative to forced unwrapping

class Person{
    
    var residence:Residence?
}


class Residence{
    var numberOfRooms:Int = 7
    
    var rooms = [Rooms]()
    var numberOfRoomsInHouse:Int{
        
        return rooms.count
    }
    
    
    subscript(i:Int)->Rooms{
        get{
            return rooms[i]
        }
        set{
            rooms[i] = newValue
        }
        
    }
    
    
    var address:Address?
    
    
    
    func numberOfRooms_()->String{
        
        return  "the number of rooms available\(numberOfRoomsInHouse)"
    }
}


class Rooms{
    
    let name:String
    init( name:String){
        self.name=name
        print("room name is \(name )")
    }
}


class Address{
    var buildingName:String?
    var buildingNumber:String?
    var street:String?
    
    func buildingIdentifier()->String?{
        if buildingNumber != nil && street != nil{
            return "building number \(buildingNumber) and street \(street)"
        }else if(buildingName != nil){
            
            return "building name is \(buildingName)"
        }else{
            return nil
        }
    }
    
    
    
    /* init(buildingName:String,buildingNumber:String,street:String){
     
     self.buildingName = buildingName
     self.buildingNumber = buildingNumber
     self.street = street
     }*/
}

let boobesh = Person()
let rooms = boobesh.residence?.numberOfRooms

print("boobesh Residence have \(rooms) rooms")


boobesh.residence = Residence()

let defaultroomsinmyhome = boobesh.residence?.numberOfRooms
print("boobesh Residence have \(defaultroomsinmyhome) rooms")

if  let defaultrooms = boobesh.residence?.numberOfRooms{
    
    print(defaultrooms )
}else {
    print("no rooms available ")
    
}

// accessing properties through optional chaining


let john=Person()
if let roomsCount = john.residence?.numberOfRoomsInHouse{
    print("johns home have \(roomsCount) rooms ")
}else {
    print("no rooms available ")
}


john.residence = Residence()

if let roomsCount = john.residence?.numberOfRoomsInHouse{
    print("johns home have \(roomsCount) rooms")
}else {
    print("no rooms available ")
}


let someAddress = Address()
someAddress.buildingNumber = "12"
someAddress.street = "Malibu point california "
john.residence?.address = someAddress

// to check method call
let result = john.residence!.numberOfRooms_

print("possible to print number of rooms\(result()) ")


// Accessing subscripts through optional chaining

// setting property of subscripts

//john.residence?[0] = Rooms(name:"happy home")

john.residence!.rooms.append(Rooms(name:"Living room "))
john.residence!.rooms.append(Rooms(name:"dining hall "))
john.residence!.rooms.append(Rooms(name:"bed room"))

// accessing subscripts value
print(john.residence![0].name)
print(john.residence![1].name)

// setting values in subscripts

john.residence![1] = Rooms(name:"Kid bedroom ")

// verifing the value which is setted

print(john.residence![1].name)



//  accessing subscripts with optional return values

var testScores = ["dave":[99,98,87],"ben":[90,98,83],"stephen":[34,56,78]]

testScores["dave"]?[0] = 100

testScores["ben"]?[0] = 40

testScores["boobesh"]?[0]=98

print(testScores["boobesh"])

print(testScores["ben"]!)


// multiple levels of optional chaining

john.residence?.address? = someAddress

print("printing address details ")

print(john.residence?.address?.buildingName)
print(john.residence?.address?.buildingNumber)
print(john.residence?.address?.street)

if let buildingIdentifier = john.residence?.address?.buildingIdentifier(){
    
    print("the building identifier is \(buildingIdentifier)")
}

// checking the return optional String   .buildingIdentifier() ?.hasPrefix("The")

if let buildingIdentifier = john.residence?.address?.buildingIdentifier(){
    
    print("the building identifier is \(buildingIdentifier)")
}else{
    
    print("building identifier dont have the prefix")
}