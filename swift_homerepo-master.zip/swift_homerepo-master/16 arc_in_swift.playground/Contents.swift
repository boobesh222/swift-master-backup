//:home Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// resolving strong reference cycles 
// weak and unowned reference cycles were used to resolve strong reference cycles 

// use weak reference if the instance has small lifetime and unowned instance for relatively longer lifetime 


// weak reference use weak 

// weak reference always declared as variables than constants and optionals .property observers were not called 


class Appartment{
    let unit:String
    init(unit:String){
        self.unit = unit
    }
    weak var tenant:person?
    deinit{
        print("appartment deinitialized")
    }
    
}
class person{
    var name:String
    
    var appartment:Appartment?
    init(name:String){
      self.name = name
        
    }
    deinit{
       print("person : booobesh the instance is deinitialized ")
    }
   
}


var referenceOne:person? = person(name:"boobesh ")

var referenceTwo = referenceOne
var referenceThree = referenceOne

// 3 strong reference is obtained

referenceOne = nil
referenceTwo = nil

// still not deinitialized

referenceThree = nil



var Boobesh:person?=person(name:"boobesh")
var unit4b:Appartment?=Appartment(unit:"4b")

Boobesh!.appartment = unit4b
unit4b!.tenant = Boobesh

// refer the diagram for more understanding 

Boobesh = nil
unit4b = nil

// unowned reference no optionals used 

class Customer {
    var name:String
    
    var card:Creditcard?
    init(name:String){
        self.name  = name
       print("initialized ")
    }
    
    deinit{
    print("customer instance deinitialized ")
    }
}


class Creditcard{
    let number:UInt64
    unowned let customer:Customer
    // UInt64 supports 16 digits card number in both 32 and 64 bit systems
    init(number:UInt64,customer:Customer){
        self.number = number
        self.customer = customer
    }
    
    deinit {
        print("credit card \(number) instancedeintialized ")
    }
}

var boobesh:Customer? = Customer(name:"Boobesh")
boobesh!.card = Creditcard(number:1234432156788765,customer:boobesh!)
boobesh = nil


// using unowned and implicitly unowned optionals 

class Country{
    
    let name:String?
    var capitalCity:City?
    
    init(name:String,capitalName:String){
       self.name=name
        self.capitalCity=City(name:name,country:self)
    }
    deinit {
        print("country class deinitialized")
    }
    
}

class City{
    let name:String
    unowned let country:Country
    init(name:String,country:Country){
       self.name=name
        self.country=country
    }
    
    deinit {
        print("city class deinitialized ")
    }
}

var country:Country?=Country(name:"India",capitalName:"newDelhi")
country = nil

// closure capture list 
// memory leak between a class and closure 

class HTMLElement{
    let name:String
    let text:String
    
    lazy var asHTML:()->String = {
        if let text:String = self.name{
            return "<\(self.name)>\(self.text)</\(self.name)>"
        }else {
           return "<\(self.name)>"
        }
    }
    
    init(name:String,text:String){
        self.name=name
        self.text=text
    }

    deinit {
        print("html element class deinitialized ")
    }
}


var heading:HTMLElement? = HTMLElement(name:"h1",text:"hello world")
heading!.asHTML()


heading = nil

// defining a capture list in swift 


// muthu's mac 

//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

print("Hello world!")

// defining a capture list

// capture list syntax

// square bracket followed by return type and in key word

// sample closure structure

// lazy var sameclosure:(Int,String)->String{
//    [unowned self, weak delegate = self.delegate! ](Index:int,stringToProcess:String)->String in

// closure body

// }


// closure without parameter list

// lazy var sameclosure:()->String = {
//    [unowned self,weak delegate = self.delegate!] in
//  }



// use unowned reference when the closure and the instance it refers are referring  to the each other

// use weak reference when the captured reference  will become nil




















