//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let names:[String] = ["aeroplane","borosil","cathedral","denmark","egypt"]

// closures in swift 
// using default method sorted 

func sortingBackward(nameOne:String,nameTwo:String) -> Bool{

    return nameTwo < nameOne
}

var results = names.sorted(by: sortingBackward)

// closures expression syntax 
// {(parameters)-> RETURNTYPE in STATEMENTS}
// parameters accepted variadic ,inout parameters, tuples 
// tuples as return type is also accepted 

// inline closures

let numbers:[Int] = [13,2,3,44,532,62,74,438,39,0]

let decendingNumbers:[Int] = numbers.sorted(by: {(n1:Int,n2:Int)-> Bool in return n2<n1})
decendingNumbers

// single expressions closures ,,return type automatically inferred
let singleexpressionresults:[Int] = numbers.sorted(by: {a1,a2 in a2<a1})
singleexpressionresults

// using shorthand arguments  $0,$1 as of in the parameter order 

// operator methods in swift 

let reversednames = names.sorted(by: >)

//trailing closures

let desnames = names.sorted() { $0 > $1 }

let nn=names.sorted{ $0 < $1 }
nn

let mapping:[Int:String]=[0:"zero",1:"one",2:"two",3:"three",4:"four",5:"five"]
mapping.sorted(by: >)

let trcresults = numbers.map(){
    $0.bigEndian
}

/// capturing values by closures from it's outer methods

func makeIncrementer(forincrementor amount:Int)->()->Int{
   var runningTotal=0
    print("inside incrementer")
    func incrementer()->Int{
        print(runningTotal)
        runningTotal += amount
        print("running total\(runningTotal)")
        return runningTotal
    }
    
    return incrementer
}




let incrementedvalue = makeIncrementer(forincrementor: 10)
incrementedvalue()
incrementedvalue()
incrementedvalue()

// @escaping syntax used before a parameter type  escaping a closures .
// a reference of closure is stored and executed only @ the end .
// and with in @escaping syntax self has to be used for refering a variable and constants

var completionHandelers:[()->Void]=[]
func somefunctionwithEscapingClosure(completionhandlerp: @escaping ()->Void){
     completionHandelers.append(completionhandlerp)
    
}

func somefunctionwithnonescapingclosures(ch:()->Void){
    
}

class someclass{
   var x=10
    func dosomething(){
        somefunctionwithEscapingClosure {
            self.x=100
            print(self.x)
        }
        somefunctionwithnonescapingclosures{
            x=500
            print(x)
        }
    }
}


let instance = someclass()
instance.dosomething()
instance.x



// autoclosures 

// lets you to delay expressions results  even after code execution 

var customersInline=["ana","bella","cathrine","daisy","eva"]

print("array count  \(customersInline.count)")
let customerprovider = {customersInline.remove(at: 0)}
print("now serving  \(customerprovider() )")


func serve(customer customerprovider:()->String){
    print("now serving  \(customerprovider() )")

}

serve(customer:{customersInline.remove(at: 0)})

// mentioning @autoclosure 


func servecustomer(customer customerProvider: @autoclosure ()->String){
  print("now serving \(customerprovider())")
}

servecustomer(customer: customersInline.remove(at: 0))

// for placing a copy of the augument which is a closure we need to define @escape  


var customerproviders:[()->String]=[]

func collectCustomerProviders(_ customer:@autoclosure @escaping ()->String){
   customerproviders.append(customer)
}

collectCustomerProviders(customerprovider())

collectCustomerProviders(customerprovider())

print(customerproviders.count)

for cust in customerproviders{
    print(cust())
}

// example for understanding @escaping 

class Apple{
    var newlyLauncheddeviceName:String = ""
    var deviceClosure:[()->String]=[]
    func getNewDeviceName(newDevice:String){
        
         newlyLauncheddeviceName=newDevice
        print(newlyLauncheddeviceName)
    }
    
    func getDeviceClosures(_ device:@escaping()->String){
          deviceClosure.append(device)
    }


    func iteration(){
        for value in deviceClosure{
              print(value())
        }

    }
    


}

var getdeviceNameforClosure={"iphone7+"}

let appleins = Apple()
appleins.getNewDeviceName(newDevice: "iphone7")
appleins.getDeviceClosures({getdeviceNameforClosure()})
appleins.iteration()


// muthu _mac 





