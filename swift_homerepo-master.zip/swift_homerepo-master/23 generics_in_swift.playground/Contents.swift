//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// generics in swift 

// mutating keyword needed for struct
// the following works only for Int

struct IntStack{

   var items = [Int]()
    mutating func push(_ item:Int){
       items.append(item)
    }

    mutating func pop()->Int{
       return  items.removeLast()
    }
}


// mutating keyword notneeded for class
class IntStackclass{
   var items = [Int]()
    func push(_ item:Int){
       items.append(item)
    }
   
    func findIndex(ofString valueToFind:String ,in array:[String])->Int?{
     
        for (Index,value) in array.enumerated(){
            if value == valueToFind{
               return Index
            }
        }
     
          return nil
        
    }
    
    
    // generic function which conforms to equatable protocol 
    
    func findTheValue<T:Equatable>(of:T,array:[T]){
        for(index,value) in array.enumerated(){
            if value == of {
               print("the corressponding index is \(index)")
            }
        }
    
    }
 
}

// representing the above function in a generic manner 

struct TeamNameStack<T>{
   var items = [T]()
    mutating func push(_ item:T){
       items.append(item)
    }
    
    
    mutating func pop()->T{
       return items.removeLast()
    }
}

var getTeamNameStack = TeamNameStack<String>()
getTeamNameStack.push("boobesh")
getTeamNameStack.push("naveen")
getTeamNameStack.push("muthupalani")
getTeamNameStack.push("ramesh")
getTeamNameStack.push("prabhu")



func getTeamMembersList(){
   
    for items in getTeamNameStack.items{
        print(items)
    }

    
}

getTeamMembersList()
print("xxxxxxxxx")
getTeamNameStack.pop()
getTeamMembersList()


// extending a stack item 

extension TeamNameStack{
    var getTopItem:T?{
        return  items.isEmpty ? nil : items[items.count - 1]
    }
    
}

getTeamNameStack.getTopItem

getTeamNameStack.pop()

getTeamNameStack.getTopItem


// type constraints in swift 
// it insists that the type parameter should adhere to certain protocol
// in  the above examples the declared T  is called the type parameter

// the so called T should conform to some class and protocol to become a type constrained type parameter 


let wildAnimals = ["tiger","lion","jaguar","cheetah","bharani"]

let indexNeeded = IntStackclass()

indexNeeded.findIndex(ofString:"jaguar",in:wildAnimals)

// making type parameter conforming to a protocol 



indexNeeded.findTheValue(of: "bharani", array: wildAnimals)
// check for results printed on the console 


let numbers = [100,78,856,525]

indexNeeded.findTheValue(of: 856, array: numbers)

// Associatated types 

//  associated types gives a placeholder name to a type that is used as a part of the protocol 

// associated type keyword is used  .the actual type is not provided until the protocol is adopted 

// associated types in action 


protocol container {
    associatedtype itemType
    mutating func append(_ item:itemType)
    var count:Int{get}
    subscript(i:Int)->itemType{get}
    
    
}

// associated types is nothing but iplementing generics for protocols 
// implemeting protocol container as a part of struct (generics )

struct ItemNameStack<T>:container{
    var items = [T]()
    mutating func push(_ item:T){
        items.append(item)
    }
    
    
    mutating func pop()->T{
        return items.removeLast()
    }
    
    // conformance to container protocol 
    
    
     // typealias itemType = Int
     // type alias used for non generic function
    
    
    mutating func append(_ item: T) {
        items.append(item)
    }
    
    var count:Int{
       return items.count
    }
    
    subscript(i:Int)->T{
     
       return items[i]
    }
    
    
    
}


// team name stack conform to the protocol container 

extension TeamNameStack:container{
    subscript(i: Int) -> T {
        return items[i]
    }

     var count: Int {
        return items.count
    }

    mutating  func append(_ item: T) {
        items.append(item)
    }

    typealias itemType = T
  
}

// where class in generics 

// use where class to check whether the type conform to a condition or a protocol 


func allItemsMatch<c1:container,c2:container>(_ firstcontainer:c1,_ secondcontainer:c2)->Bool where c1.itemType == c2.itemType ,c1.itemType:Equatable{

    if  firstcontainer.count != secondcontainer.count{
        return false
    }

    for item in 0..<firstcontainer.count{
        if firstcontainer[item] != secondcontainer[item]{
           return false
        }
    }
    
    return true
    
}


var stringstack=ItemNameStack<String>()
stringstack.push("hello")
stringstack.push("hola")
stringstack.push("bonjour")
stringstack.push("vanakam")


var itemstack=TeamNameStack<String>()

itemstack.push("hello")
itemstack.push("hola")
itemstack.push("bonjour")
itemstack.push("vanakam")

allItemsMatch(stringstack, itemstack)




