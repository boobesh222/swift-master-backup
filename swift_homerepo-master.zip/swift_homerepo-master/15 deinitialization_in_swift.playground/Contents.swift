//: home Playground - noun: a place where people can play

import UIKit 

var str = "Hello, playground"

// deinitializers are called before a class object is deallocated 
// should use deinit keyword
// availabe only for class types 

// deinit syntax 

class unknown {
    deinit{
        
        
    }

}

class Bank{
   static var  coinsInBank = 10_000_000
    static func distributeCoins(coins numberOfCoinsRequested:Int)->(Int){
       let numberOfCoinsToVend = min(numberOfCoinsRequested, coinsInBank)
        print(numberOfCoinsToVend)
        
        coinsInBank -= numberOfCoinsToVend
        return numberOfCoinsToVend
    }

    static func receiveCoins(coins:Int){
      coinsInBank += coins
    }
}

class PlayerOne{
    var coinsInPurse:Int
    init(coins:Int){
      coinsInPurse = Bank.distributeCoins(coins: coins)
    }
    
    func win(coins:Int){
      coinsInPurse += Bank.distributeCoins(coins: coins)
    }
    
    deinit{
      Bank.receiveCoins(coins: coinsInPurse)
    }
}

var player:PlayerOne? = PlayerOne(coins:5000)
player!.coinsInPurse

player!.win(coins: 890)
player!.coinsInPurse

Bank.coinsInBank

// player object is deinitialized here
player = nil

Bank.coinsInBank
















