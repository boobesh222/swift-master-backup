//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// error handling in swift 

// in swift errors are represented by values of type which conform to ERROR protocol
// enum are suited for representing errors 

// use throw statement to throw a error

enum VendingMachineError:Error{
    
    case invalidSelection
    case insufficientMoney(coins:Int)
    case outOfStock
    

}

// example for throw

throw VendingMachineError.insufficientMoney(coins: 5)

// four ways to handle errors in swift  using do - catch ,assert ,use optionals 
// also  do use try keyword try? and try!


// windows machine playground 

//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

print("Hello world!")
// error handling in swift done in four ways

// do-catch ,optional  and assert

// use try keyword ans try! and try?

// propagating errors through throw functions

//enum VendingMachineError:Error{
//    
//    case invalidSelection
//    case insufficientFunds(coinsNeeded:Int)
//    
//    case outOfStock
//}



struct Item {
    
    var price:Int
    var count:Int
    
}


class VendingMachine{
    var inventory=["candyBar":Item(price:2,count:5),
                   "chips":Item(price:4,count:7),
                   "toffee":Item(price:5,count:8)
    ]
    
    var coinsDeposited = 0
    
    func vend(itemNamed name:String)throws{
        
        guard let item = inventory[name] else{
            print("first guard")
            throw VendingMachineError.invalidSelection
        }
        
        guard item.count > 0 else{
            
            print("second guard")
            throw VendingMachineError.outOfStock
        }
        
        guard item.price <= coinsDeposited else{
            
            print("third guard")
            throw VendingMachineError.insufficientMoney(coins:item.price-coinsDeposited)
        }
        
        coinsDeposited -= item.price
        
        var newitem = item
        newitem.count -= 1
        
        inventory[name]=newitem
        
        print("dispensing \(name)")
        
    }
    
    
    
}




let favouriteSnacks = ["bob":"locorice","alice":"chips","boobesh":"toffee"]

func buyFavouriteSnack(person:String,vendingmachine:VendingMachine)throws{
    
    let snackName = favouriteSnacks[person] ?? "candyBar"
    print("buy favourite snacks ")
    print()
    //  try keyword used
    
    try vendingmachine.vend(itemNamed:snackName)
    
    
    
    
    
}

var vendingmachineInstance = VendingMachine()
try? buyFavouriteSnack(person:"faizon",vendingmachine:vendingmachineInstance)

/*switch VendingMachineError{
 
 case self.outOfStock:
 print("the item which you are looking for is out of stock")
 
 default:
 print("error in code ")
 }*/


// using do catch statement for propagating error

var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 9
do {
    try buyFavouriteSnack(person:"bob",vendingmachine:vendingMachine)
}catch VendingMachineError.outOfStock{
    print("outofstock")
}catch VendingMachineError.invalidSelection{
    print("invalidselection")
}catch VendingMachineError.insufficientMoney(coins:9){
    print("insufficient funds ")
}


// converting errors to optionals


func someThrowingFunction()throws->Int{
    
    print("some throwing function ")
    throw VendingMachineError.outOfStock
    return 0
}

// error is converted to optional in swift
do{
    
    var x=try? someThrowingFunction()
    print(x)
} catch VendingMachineError.outOfStock{
    print("outof stock ")
}

// disabling error propagation in swift not running in ibm

/*do{
 
 var x=try someThrowingFunction()
 print(x)
 } catch VendingMachineError.outOfStock{
 print("outof stock ")
 }
 */


// some samples left
//  use defer statement to execute a block of code which is to be executed before leaving the current block
// defer should not contain break , return ,and throw statements




