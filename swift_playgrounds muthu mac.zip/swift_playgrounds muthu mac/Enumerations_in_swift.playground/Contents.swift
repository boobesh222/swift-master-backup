//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// enumerations in swift
 // user defined datatype in swift with its own value 
// enum structure 

enum Planet{
  case earth
  case mars
  case jupiter
  case venus
  case uranus
}

// planet has its own datatype 
// each case has its own INT VALUE


var result = Planet.earth
result.hashValue
Planet.jupiter.hashValue

result = .uranus

result = .venus

switch result {

case .earth:
    print("3 planet")
case .mars:
    print("4 planet")
case .jupiter:
    print("5 th planet")
case .uranus:
    print("uranus ")
case Planet.venus:
    print("venus second planet")
default:
    print("printing default value ")
}


// associated value sin enumerations in swift
// asso values allows us to store additional values to the case values

		




















