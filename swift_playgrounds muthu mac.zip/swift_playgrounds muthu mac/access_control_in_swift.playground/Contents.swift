//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// access control in swift 


//  same as access modifiers in swift 

// modules and source files 
// module is a single unit of code distribution -- collection of codes can be used by import keyword .each build target(app bundle or library or framework is treated as module)
// source code files are the files with in the modules 


// five different access levels in swift 

// open access , public access , private access ,internal access ,file private access 


// open access and public access can be accessed from  any part of the defyning module and the adoption 

// internal access enables access from any source files from inside the module and not from outside the module 

// file private access enables access from only the source file which  is written inside the module ...the codes are only file specific 

// private access can be used only within the declaration


// refer access controls in swift 
// open access applies only to class and class members 

// access control syntax 

public class SomepublicClass{}
internal class SomeInternalClass{}
fileprivate class SomeFilePrivateClass{}
private class SomePrivateClass{}

public var somePublicVariable = 0
internal let someIntenalConstant = 0
fileprivate func someFilePrivateFunction() {}
private func somePrivateFunction(){}


// access specifiers are by default internal and the above mentioned specifiers with the internal keyword can be written without the internal keyword 


// public types will have only internal members and not public members 


public class SomePublicClass{
        // explicitly defined internal class
     public var somePublicProperty = 0  // explicitly public class member 
     var somePubvariable = 0 // implicit class member 
     fileprivate func someFilePrivateFunction(){} // ex file private function
     private func somePrivateFunction() {} // explicitlt private function
    
}

class someInternalClass{
    var someIntenalProperty = 0 // implicitly declared class property 
    fileprivate func someFilePrivateFunction(){} // ex file private function
    private func somePrivateFunction() {} // explicitlt private function

    
}

fileprivate class someFilePrivateClassMember{
    
    func someprivatemethod(){} // implicitly fileprivate class member 
    
    private func someprivateMethod(){} // private class member 
    
    
 
}


private class SomeClass {
     // explicitly private class 
    
    func somePrivateMethod(){}
       // explicitly private method
 
}


// access level in tuple types 


















