//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// reference counting applies to the instance of classes
// not applicable to struct and enum 	

// sample example with arc 

class 	Person{
    var name:String
    init(name:String){
       self.name = name
       print("person class is initialized ")
    }
    deinit{
      print("class is deinitialzed ")
    }
}


var referenceOne:Person? = Person(name:"boobesh ")

var referenceTwo = referenceOne
var referenceThree = referenceOne

// 3 strong reference is obtained 

referenceOne = nil
referenceTwo = nil

// still not deinitialized 

referenceThree = nil

