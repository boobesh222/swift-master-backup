//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// type properties 
// properties of specific type such as emum ,struct,class etc 
// stored / computed type properties in emum and struct  should be initialized with static keyword and
// stored type properties of class should be declared with static and computed type properties should be declared in class with class keyword 



struct AudioChannel{
  static let thresholdlevel = 10
  static var maxInputLevelForAllChannels = 0
    var currentLevel:Int = 0{
        didSet{
            if currentLevel > AudioChannel.thresholdlevel{
               currentLevel = AudioChannel.thresholdlevel
              print("did set called ")
            }
            
            if currentLevel > AudioChannel.maxInputLevelForAllChannels{
               currentLevel = AudioChannel.maxInputLevelForAllChannels
            }
        }
    }
}

var leftsterio = AudioChannel()
var rightSterio = AudioChannel()

leftsterio.currentLevel = 7

print(leftsterio.currentLevel)
print(AudioChannel.thresholdlevel)
print(AudioChannel.maxInputLevelForAllChannels)

class android{
    
    static var legacyosversion:String = "eclair"
    static var previousVersion:String = "marshmellow"
    class var osVersion:String{
       return "nougat"
    }

   var androidclassinstance = "gingerbread"
}


var androidInstance = android()

androidInstance.androidclassinstance
android.osVersion























