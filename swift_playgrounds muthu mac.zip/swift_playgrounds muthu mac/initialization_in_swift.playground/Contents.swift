//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// initializer delegation in swift 
// use self.init to refer to other initializer of the same type 


// defining cuatom initializer will prevent access to default initializers in structure 

struct Point {
   var x = 0.0 ,y = 0.0
}

struct Size{
  var width = 0.0 ,height = 0.0
}

struct rect{
  var origin = Point()
    var size = Size()
    
    
    // default initializers
    init(){}
    
    // memberwise initializers 
    
    init(origin:Point ,center:Size){
     self.origin = origin
     self.size = center
     print("member wise initializer invoked with the origin and center value ")
    }
    
    // delegates which call other method
    init(center:Point,size:Size){
        
        let originX = center.x - (size.width/2)
        let originY = center.y - (size.height/2)
    
        // invokes other initializer from this initializer
        self.init(origin:Point(x:originX, y:originY),center:size)
    
    }
    
}


let rectangleCoordinates = rect(center:Point(x:3,y:7),size:Size(width:76,height:99))


// class type initializers 
// two types 1) designated initializers and 2)convinience initializers 

// designated initiailzers are the default initilaizers fot the class.initialization happens upto super class chain 

// convinience initializers are the secondary initializers for the class  

// create convinience initializer for shorter and clearer initialisation process .use them to initialize designated initializer 

// designated and convinience syntax as follows 


//  init( paramenters ){

//   }

//  convience init( parameters ){

//  }

// refer initializer delegation and two phase delegation 







